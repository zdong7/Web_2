echo "# Web_2" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/zdong7/Web_2.git
git push -u origin master